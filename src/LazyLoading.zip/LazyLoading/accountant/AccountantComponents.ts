import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Accountant.html'

})
export class AccountantClass{
    
} 