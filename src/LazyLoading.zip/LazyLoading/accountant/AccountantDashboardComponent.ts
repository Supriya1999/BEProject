import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'AccountantDashboard.html'

})
export class AccountantDashboardClass{
    
} 