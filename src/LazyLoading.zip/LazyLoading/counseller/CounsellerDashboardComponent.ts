import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'CounsellerDashboard.html'
})
export class CounsellerDashboardClass{

}