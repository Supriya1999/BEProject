import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Counseller.html'
})
export class CounsellerMainClass{

} 