import { templateJitUrl } from "@angular/compiler"
import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Super_userDashboard.html',
})
export class SuperUserDashboardClass{

}