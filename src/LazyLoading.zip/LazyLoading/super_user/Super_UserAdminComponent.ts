import { templateJitUrl } from "@angular/compiler"
import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Super_userAdmin.html',
})
export class SuperUserAdminMainClass{

}