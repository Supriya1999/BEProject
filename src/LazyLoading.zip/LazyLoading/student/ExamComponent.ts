import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Exam.html'

})
export class ExamClass{
    
} 