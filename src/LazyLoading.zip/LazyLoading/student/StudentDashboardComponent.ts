import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'StudentDashboard.html'

})
export class StudentDashboardClass{
    
}