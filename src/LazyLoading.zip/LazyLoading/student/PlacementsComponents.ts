import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Placements.html'

})
export class PlacementsClass{
    
}