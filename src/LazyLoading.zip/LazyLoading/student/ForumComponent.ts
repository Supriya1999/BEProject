import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Forum.html'

})
export class ForumClass{
    
}