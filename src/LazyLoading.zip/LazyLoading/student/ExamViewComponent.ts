import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'ExamView.html'

})
export class ExamViewClass{
    
}