import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Fees.html'

})
export class FeesClass{
    
}