import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'Study.html'

})
export class StudyClass{
    
}