import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'CoursesView.html'

})
export class CoursesViewClass{
    
}