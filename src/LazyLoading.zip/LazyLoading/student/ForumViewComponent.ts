import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'ForumView.html'

})
export class ForumViewClass{
    
}