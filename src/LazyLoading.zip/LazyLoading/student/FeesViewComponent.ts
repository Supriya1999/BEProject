import {Component} from '@angular/core'
@Component({
    selector:'app-root',
    templateUrl:'FeesView.html'

})
export class FeesViewClass{
    
}