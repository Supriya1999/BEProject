export class ApiUrl{
    getUrl():any{
        return "http://localhost:8000/";
    }
}