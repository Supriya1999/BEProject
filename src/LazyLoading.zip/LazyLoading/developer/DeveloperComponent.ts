import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Developer.html'
})
export class DeveloperMainClass{

}