import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'DeveloperDashboard.html'
})
export class DeveloperDashboardClass{

}