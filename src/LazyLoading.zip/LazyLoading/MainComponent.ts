import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Main.html'
})
export class MainClass{
    
}