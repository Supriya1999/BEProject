import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Admin.html',
})
export class AdminMainClass{

}