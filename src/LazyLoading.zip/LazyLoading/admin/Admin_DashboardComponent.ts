import {Component} from "@angular/core"
@Component({
    selector:'app-root',
    templateUrl:'Admin_Dashboard.html',
})
export class DashboardClass{

}